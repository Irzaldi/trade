/**
 * Crypto Risk Tool — Cloudflare Worker Proxy
 * Deploys to: https://crypto-proxy.<your-subdomain>.workers.dev
 *
 * This Worker sits between your browser and crypto exchange APIs.
 * It removes the need for any CORS proxy middlemen — direct, fast calls.
 */

// Allowed exchange API domains (whitelist for security)
const ALLOWED_DOMAINS = [
  'api.binance.com',
  'www.okx.com',
  'api.bybit.com',
  'api.mexc.com',
  'api.gateio.ws',
  'api.kucoin.com',
  'indodax.com',
  'api.alternative.me',
];

export default {
  async fetch(request, env, ctx) {
    // Handle CORS preflight
    if (request.method === 'OPTIONS') {
      return new Response(null, {
        headers: corsHeaders(),
      });
    }

    const url = new URL(request.url);

    // Health check endpoint
    if (url.pathname === '/health') {
      return jsonResponse({ status: 'ok', worker: 'crypto-proxy', ts: Date.now() });
    }

    // Main proxy endpoint: GET /proxy?url=https://api.binance.com/...
    if (url.pathname === '/proxy') {
      const targetUrl = url.searchParams.get('url');

      if (!targetUrl) {
        return jsonResponse({ error: 'Missing ?url= parameter' }, 400);
      }

      // Validate the target URL is an allowed exchange
      let targetHost;
      try {
        targetHost = new URL(targetUrl).hostname;
      } catch (e) {
        return jsonResponse({ error: 'Invalid URL' }, 400);
      }

      if (!ALLOWED_DOMAINS.includes(targetHost)) {
        return jsonResponse({ error: `Domain not allowed: ${targetHost}` }, 403);
      }

      // Fetch from the exchange directly (Worker has no CORS restrictions)
      try {
        const response = await fetch(targetUrl, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (compatible; CryptoRiskTool/1.0)',
            'Accept': 'application/json',
          },
          // 8 second timeout (generous — direct calls are fast)
          signal: AbortSignal.timeout(8000),
        });

        const data = await response.text();

        return new Response(data, {
          status: response.status,
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders(),
          },
        });
      } catch (e) {
        return jsonResponse({
          error: 'Fetch failed',
          message: e.message,
          target: targetUrl,
        }, 502);
      }
    }

    // 404 for anything else
    return jsonResponse({ error: 'Not found. Use GET /proxy?url=<exchange_url>' }, 404);
  },
};

function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };
}

function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json',
      ...corsHeaders(),
    },
  });
}
